import socket
from threading import Timer
client = socket.socket()            #Declaring Client
host = '127.0.0.1'                  #IP address of the server(here: Local host)
port = 1995                         #Should be same as Server port

client.connect((host, port))
print("Connected established with Twincat3 Server")

starting_val =0                     #initial value for integer transfer sequence
counter =0                          #for integer sequence
transfer_rate = 100                 #in ms


mode_selection=(input(' MODE SELECTION: For sample integer data transfer enter 3;''For checking the toggle_bit status of PLC enter 2;''To control the Grippers enter 1: '))
print(mode_selection)

def Int_transfer():     #Integer back and forth transfer
    
    global counter, thread_transfer, Duration, starting_val,transfer_rate
    Duration = 20
    if counter >= Duration:
         exit
    else:
         starting_val= starting_val+1 
         client.send(str(starting_val).encode('utf-8'))       #Encoding and sending the value to the server
         dataOut = client.recv(1024)                          #Receiving and decoding the data from server 
         print(dataOut.decode('utf-8'))
         thread_transfer = Timer((transfer_rate/1000),Int_transfer) # transfer_rate = 100ms : the time for data transmission
         counter= counter + (transfer_rate/1000)
         thread_transfer.start()
def Bit_status():
    client.send('Toggle_State'.encode('utf-8')) #for getting toggle state feedback
    dataOut = client.recv(1024)                 # status from memory bit
    print(dataOut.decode('utf-8'))
        
        
while(1):                                                      #for continous sequence
   if mode_selection =='1':                                    #for gripper control
      dataIn = input('Gripper Control: \n'
                     'For Gripper 1:Enter ongripper1: \n'
                     'For Gripper 2:Enter Ongripper2: \n'
                     'For Gripper 3:Enter ongripper3: \n'
                     'For Gripper 4:Enter ongripper4:')
      client.send(bytes(dataIn,'utf-8'))
      dataOut = client.recv(1024)
      print(dataOut)                                   
   elif mode_selection =='2':                                   #for togglebit feedback
       Bit_status()
   elif mode_selection =='3':                                   # for integer transfer
       Int_transfer()
   else:
      mode_selection=(input(' MODE SELECTION: For sample integer data transfer enter 3;''for checking the toggle_bit status of PLC enter 2;''to control the Grippers enter 1: '))
